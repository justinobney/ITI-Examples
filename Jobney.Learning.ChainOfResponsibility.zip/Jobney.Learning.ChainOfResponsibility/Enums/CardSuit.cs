namespace Jobney.Learning.ChainOfResponsibility.Enums
{
    public enum CardSuit
    {
        Hearts,
        Spades,
        Diamonds,
        Clubs
    }
}